using Test
using EcoAcoustics
using Dates

@testset "Audiodata basic construction" begin
    sig = randn(1_000)
    fs  = 48_000      # Hz as Real
    t0  = DateTime(2025, 1, 1, 0, 0, 0)
    t1  = t0 + Dates.Second(1)

    aud = EcoAcoustics.Audiodata(
        sig,
        fs,
        t0;
        endtime        = t1,
        timezone       = "UTC",
        lat            = 38.5,
        lon            = -74.5,
        site_id        = "A5M",
        recorder       = "Rockhopper",
        recorder_id    = "RH428",
        calibration    = EcoAcoustics.NoCalibration(),
    )

    @test aud.sig isa Vector{Float64}
    @test length(aud.sig) == 1_000

    @test aud.fs == 48_000f0
    @test aud.starttime == t0
    @test aud.endtime   == t1

    @test aud.timezone == "UTC"
    @test aud.lat == 38.5
    @test aud.lon == -74.5
    @test aud.site_id == "A5M"
    @test aud.recorder == "Rockhopper"
    @test aud.recorder_id == "RH428"
    @test aud.calibration isa EcoAcoustics.NoCalibration
end

@testset "Audiodata invariants" begin
    sig = randn(1_000)
    fs  = 48_000
    t0  = DateTime(2025, 1, 1)
    t1  = t0 + Dates.Second(1)

    # Valid construction: endtime inferred if omitted
    aud = EcoAcoustics.Audiodata(sig, fs, t0)
    @test aud.fs == 48_000f0
    @test aud.endtime ≥ aud.starttime

    # fs must be positive
    @test_throws ArgumentError EcoAcoustics.Audiodata(sig, 0, t0)

    # endtime must be ≥ starttime
    @test_throws ArgumentError EcoAcoustics.Audiodata(
        sig, fs, t1;
        endtime = t0,
    )
end
