```markdown
# Filename parsing and recorder profiles

EcoAcoustics.jl separates two concerns:

1. **Reading audio samples** (handled by `read_audio`)
2. **Understanding filenames** (handled by `parse_filename` + `RecorderProfile`)

This page explains how to:

- Use built-in recorder profiles,
- Provide metadata manually when filenames are unstructured,
- Add your own recorder profile,
- (Optionally) write a custom filename parser for unusual formats.

---

## 1. Using built-in recorder profiles

EcoAcoustics.jl includes built-in rules for several recorder families:

- `rockhopper`
- `sm3m`
- `ls1x`
- `snap` (renamed files like `T3C_180630_235000.wav`)

You select a recorder via `read_audio`:

```julia
using EcoAcoustics

ad = read_audio("139635MD01_197K_A6M_RH428_20231012_000654Z.flac";
                recorder = "rockhopper")
```

Internally this calls:

```julia
meta = parse_filename("139635MD01_197K_A6M_RH428_20231012_000654Z.flac";
                      recorder = "rockhopper")
```

producing:

```julia
(timestamp   = DateTime("2023-10-12T00:06:54"),
 timezone    = "UTC",
 lat         = missing,
 lon         = missing,
 site_id     = "A6M",
 recorder_id = "RH428")
```

`read_audio` then merges:

- filename metadata,
- recorder defaults,
- future sidecar/XML metadata,
- user overrides,

and constructs an `Audiodata` object.

---

## 2. Providing metadata manually

If your filenames have no structure or you prefer full control:

```julia
using Dates, EcoAcoustics

ad = read_audio("mystery_001.wav";
                recorder  = "unknown",
                starttime = DateTime(2021, 5, 1, 12, 0, 0),  # UTC
                lat       = 38.5,
                lon       = -74.5,
                site_id   = "MAB01")
```

In this case:

- `parse_filename` finds no profile,
- emits a warning,
- returns all metadata as `nothing`/`missing`,
- your provided metadata populates the final `Audiodata`.

This approach is safest for messy or inconsistent archives.

---

## 3. Adding a new recorder profile

Define recorder behavior by adding a `RecorderProfile` entry in `recorder_profiles.jl`.

### 3.1 Example: tokenized filenames

Suppose filenames follow:

```
ST01_20250101_120000_ID42.wav
```

Where:

- `ST01` = site ID  
- `20250101` = date  
- `120000` = time  
- `ID42` = recorder ID  

Add the profile:

```julia
RECORDER_PROFILES["soundtrap"] = RecorderProfile(
    "SoundTrap",
    :tokenized,
    '_',                  # split_char
    2,                    # date_token      ("20250101")
    3,                    # time_token      ("120000")
    nothing,              # datetime_token  (unused)
    "yyyymmdd_HHMMSS",    # datetime_format
    1,                    # site_token      ("ST01")
    4,                    # recorder_id_token ("ID42")
    :none,                # timezone_source
    false,                # has_xml
    nothing,              # parser
)
```

Parse it:

```julia
meta = parse_filename("ST01_20250101_120000_ID42.wav";
                      recorder = "soundtrap")
```

Results:

- `timestamp == DateTime(2025,1,1,12,0,0)`
- `site_id == "ST01"`
- `recorder_id == "ID42"`
- `timezone === nothing`

### 3.2 Testing your new profile

Add:

```julia
@testset "SoundTrap filename parsing" begin
    fname = "ST01_20250101_120000_ID42.wav"
    meta  = EcoAcoustics.parse_filename(fname; recorder = "soundtrap")

    @test meta.site_id     == "ST01"
    @test meta.recorder_id == "ID42"
    @test meta.timestamp   == DateTime(2025, 1, 1, 12, 0, 0)
    @test meta.timezone    === nothing
end
```

---

## 4. Unknown recorders and no generic fallback

If you call:

```julia
parse_filename("foo_20200101_120000.wav"; recorder="mysterybox")
```

EcoAcoustics.jl:

- emits a warning: unknown recorder,
- returns:

```julia
(timestamp   = nothing,
 timezone    = nothing,
 lat         = missing,
 lon         = missing,
 site_id     = nothing,
 recorder_id = nothing)
```

There is **no generic guessing logic**.

Why?

- Guessing timestamps/site IDs is error-prone.
- Silent mis-parsing is dangerous in scientific workflows.
- Explicit profiles or explicit metadata are safer.

You must either:

- define a `RecorderProfile`, or  
- supply metadata manually via `read_audio`.

---

## 5. Optional: custom parser functions (e.g., SNAP YYMMDD)

Some recorders require more than token positions.

Example SNAP-style filename:

```
T3C_180630_235000.wav
```

where:

- `T3C` = site ID  
- `18` = 2018  
- `0630` = June 30  

Define a helper parser:

```julia
function _parse_snap_filename(basename_noext::AbstractString)
    tokens = split(basename_noext, '_')
    if length(tokens) < 3
        return (timestamp   = nothing,
                timezone    = nothing,
                lat         = missing,
                lon         = missing,
                site_id     = nothing,
                recorder_id = nothing)
    end

    site_id = tokens[1]
    date6   = tokens[2]   # "180630"
    time    = tokens[3]   # "235000"

    if length(date6) != 6
        return (timestamp   = nothing,
                timezone    = nothing,
                lat         = missing,
                lon         = missing,
                site_id     = site_id,
                recorder_id = nothing)
    end

    full_date = "20" * date6                      # "20180630"
    dtstr     = full_date * "_" * time            # "20180630_235000"
    ts = DateTime(dtstr, DateFormat("yyyymmdd_HHMMSS"))

    return (timestamp   = ts,
            timezone    = nothing,
            lat         = missing,
            lon         = missing,
            site_id     = site_id,
            recorder_id = nothing)
end
```

Register the profile:

```julia
RECORDER_PROFILES["snap"] = RecorderProfile(
    "SNAP (renamed)",
    :tokenized,
    '_',
    2,                      # date token ("180630")
    3,                      # time token ("235000")
    nothing,
    "yyyymmdd_HHMMSS",
    1,                      # site token ("T3C")
    nothing,                # recorder ID not present
    :none,
    false,
    _parse_snap_filename,   # custom parser
)
```

This method is optional and only needed for irregular formats.

---

## 6. How this connects to `read_audio`

`read_audio` performs:

1. `meta = parse_filename(path; recorder=...)`
2. merges:
   - filename metadata,
   - recorder-specific defaults,
   - user-specified metadata,
   - (future) XML/sidecar metadata,
3. constructs an `Audiodata` struct with:
   - audio samples (`sig`)
   - sampling rate (`fs`)
   - timestamps (`starttime`, `endtime`)
   - location (`lat`, `lon`)
   - site ID, recorder ID
   - timezone
   - and calibration metadata (Phase I/II)

This system is intentionally:

- explicit,
- transparent,
- testable,
- reproducible.

No silent guessing. Filename rules are always visible in code.

```
