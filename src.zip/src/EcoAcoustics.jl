module EcoAcoustics

using Dates

include("audio/calibration.jl")
include("recorders/recorder_calibrations.jl")
include("audio/Audiodata.jl")

include("recorders/recorder_profiles.jl")
include("audio/parse_filename.jl")
include("audio/read_audio.jl")


end
