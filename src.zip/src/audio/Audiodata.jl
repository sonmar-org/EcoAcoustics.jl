"""
    Audiodata

Container for a single mono audio recording plus its associated metadata.

Fields
------
- `sig::Vector{Float64}`:
    Mono audio samples in linear amplitude units. This is always stored as
    `Float64`, regardless of the original on-disk type.

- `fs::Float32`:
    Sampling rate in Hz. Must be strictly positive.

- `starttime::DateTime`:
    Start timestamp of the recording and is always UTC.

- `endtime::DateTime`:
    End timestamp of the recording and is always UTC. Must be ≥ `starttime`.

- `timezone::Union{String,Nothing}`:
    Timezone records the original local timezone ("America/New_York", "UTC", or nothing if unknown).

- `lat::Union{Float64,Missing}` / `lon::Union{Float64,Missing}`:
    Optional latitude/longitude of the recorder location, in degrees.

- `site_id::Union{String,Nothing}`:
    Optional site or deployment identifier (e.g. "MAB01"). `nothing` if unknown.

- `recorder::String`:
    Description or ID for the recorder/hydrophone chain (e.g. "Rockhopper A1").

- `recorder_id::Union{String,Nothing}`:
    ID of recorder or Serial number. Usually NOT the hydrophone serial number, which may be separate from the recorder. `nothing` if unknown.

- `calibration::Calibration`:
    Calibration description, *not* applied to `sig`. This can be:
      - `NoCalibration()`        : no calibration info available
      - `ScalarCalibration(...)` : single total sensitivity in dB
      - `TFCalibration(...)`     : frequency-dependent TF in dB

Notes
-----
- The raw signal `sig` is always uncalibrated. Calibration is applied later
  during metric computation (e.g. SPL/PSD), not at the I/O stage.
- Use `duration(a)` and `nsamples(a)` helper functions for convenience.
"""
struct Audiodata
    sig::Vector{Float64}
    fs::Float32
    starttime::DateTime
    endtime::DateTime
    timezone::Union{String,Nothing}
    lat::Union{Float64,Missing}
    lon::Union{Float64,Missing}
    site_id::Union{String,Nothing}
    recorder::String
    recorder_id::Union{String,Nothing}
    calibration::Calibration

    function Audiodata(sig::AbstractVector{<:Real},
                       fs::Real,
                       starttime::DateTime;
                       endtime::Union{DateTime,Nothing}=nothing,
                       timezone::Union{String,Nothing}=nothing,   # IANA name, or nothing
                       lat::Union{Float64,Missing}=missing,
                       lon::Union{Float64,Missing}=missing,
                       site_id::Union{String,Nothing}=nothing,
                       recorder::AbstractString="unknown",
                       recorder_id::Union{String,Nothing}=nothing,
                       calibration::Calibration=NoCalibration())
        
        isempty(sig) &&
            throw(ArgumentError("Audiodata: signal vector is empty."))

        fs <= 0 &&
            throw(ArgumentError("Audiodata: sampling rate fs must be > 0, got $fs."))

        # Normalize numeric types
        sig64 = Float64.(sig)
        fs32  = Float32(fs)

        # If endtime not provided, infer it from starttime and number of samples
        if endtime === nothing
            dur_s   = length(sig64) / fs32
            endtime = starttime + Millisecond(round(Int, dur_s * 1000))
        elseif endtime < starttime
            throw(ArgumentError("Audiodata: endtime ($endtime) < starttime ($starttime)."))
        end

        new(sig64, fs32, starttime, endtime, timezone, lat, lon, site_id,
            String(recorder), recorder_id, calibration)
    end
end

# Helper functions
"Return the duration of this recording as a Period (endtime - starttime)."
duration(a::Audiodata) = a.endtime - a.starttime

"Return the number of samples in this recording."
nsamples(a::Audiodata) = length(a.sig)
