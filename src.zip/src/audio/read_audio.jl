using FileIO: load
using Dates
using WAV: wavread

# Internal: normalize FileIO.load outputs into (sig::Vector{Float64}, fs::Float32)
function _normalize_loaded_audio(x)
    if x isa Tuple
        # WAV.jl: (data, fs, nbits, chunks) or (data, fs)
        data = x[1]
        fs   = x[2]
    else
        # LibSndFile/FileIO: SampleBuf from SampledSignals.jl
        data = Array(x)                     # N or N×C
        fs   = getfield(x, :samplerate)     # SampleBuf has this field
    end
    sig =
        data isa AbstractVector ? Float64.(data) :
        (data isa AbstractMatrix && size(data, 2) == 1) ? Float64.(vec(data[:, 1])) :
        error("Only mono audio supported. Got array of size $(size(data)).")

    return sig, Float32(fs)
end


"""
    read_audio(path; starttime, recorder="unknown", cal=0.0f0,
               lat=missing, lon=missing, site_id=nothing)

Read an audio file using FileIO and return an `Audiodata` struct.

This function:
- uses `FileIO.load` to read the file,
- normalizes backend differences with `_normalize_loaded_audio`,
- fills in start/end times and basic metadata,
- does **not** apply any calibration or DSP.

Only mono audio is currently supported.
"""
function read_audio(path::AbstractString;
                    starttime::DateTime = DateTime(0),  # unknown start time default
                    recorder::AbstractString = "unknown",
                    lat::Union{Float64,Missing} = missing,
                    lon::Union{Float64,Missing} = missing,
                    site_id::Union{String,Nothing} = nothing,
                    strict::Bool = false)

    ext = lowercase(splitext(path)[2])

    # filename metadata + calibration
    filename_meta = parse_filename(path; recorder=recorder, strict=strict)
    cal  = lookup_calibration(path, recorder, filename_meta; strict=strict)


    ! Check to see what parsing returns.  Defaults are given so they should just pass through parser.
      starttime and site_id
    - will need lookup for site id
    - why need nsamples, endtime and duration?  aren't there helpers already? do they need to be in metadata?



    
    raw =
        ext == ".wav"  ? wavread(path) :
        # everything else (flac, aif, etc.) via FileIO/LibSndFile:
        load(path)
    
    sig, fs = _normalize_loaded_audio(raw)

    nsamples = length(sig)
    duration_s = nsamples / fs
    endtime = starttime + Millisecond(round(Int, 1000 * duration_s))

   return Audiodata(sig, fs, starttime;
                     endtime      = endtime,
                     timezone     = nothing,          # until we hook in parse_filename
                     lat          = lat,
                     lon          = lon,
                     site_id      = site_id,
                     recorder     = String(recorder),
                     recorder_id  = meta.recorder_id,
                     calibration  = cal)  # Phase I stub
end

