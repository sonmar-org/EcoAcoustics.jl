abstract type Calibration end

"Marker type indicating that no calibration info is available."
struct NoCalibration <: Calibration
end

"Single total sensitivity in dB re 1 µPa (or 1 Pa, depending on environment)."
struct ScalarCalibration <: Calibration
    sens_db::Float32
end

"Frequency-dependent transfer function in dB, defined on given frequencies."
struct TFCalibration <: Calibration
    freqs::Vector{Float32}   # Hz
    tf_db::Vector{Float32}   # dB at those freqs
end

# usage
# apply_calibration(Pss, freqs, ::NoCalibration) = Pss
# apply_calibration(Pss, freqs, cal::ScalarCalibration) = ...
# apply_calibration(Pss, freqs, cal::TFCalibration) = ...
