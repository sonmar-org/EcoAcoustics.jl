"""
    RecorderProfile

Metadata describing how a specific recorder family encodes information
in its filenames.

A `RecorderProfile` tells `parse_filename` how to split the basename,
which tokens correspond to date/time/site/recorder_id, and (optionally)
provides a custom `parser` function for recorders with non-standard or
ambiguous formats (e.g. SNAP's 2-digit year).

Fields
------
- `filename_style::Symbol`:
      Currently `:tokenized`. Determines how the basename is interpreted.

- `split_char::Union{Char,Nothing}`:
      Character used to split the filename into tokens.

- `date_token`, `time_token`, `datetime_token`:
      Token indices specifying where date/time fields appear.
      Only one of `datetime_token` or (`date_token` + `time_token`) is used.

- `datetime_format::Union{String,Nothing}`:
      A `Dates.DateFormat` string describing how to parse the combined
      date/time string.

- `site_token`, `recorder_id_token`:
      Token indices for site/deployment identifiers and recorder IDs.

- `timezone_source::Symbol`:
      How to infer timezone (e.g. `:suffix_Z` for Rockhopper). `:none` otherwise.

- `has_xml::Bool`:
      Whether this recorder type may supply additional metadata via an XML file.

- `parser::Union{Nothing,Function}`:
      Optional recorder-specific function that overrides all generic parsing.
      Used for cases like SNAP where filename rules require custom logic.

Notes
-----
Recorder profiles make filename parsing explicit and reproducible.
Unknown recorders do not use generic heuristics; all metadata fields
default to `nothing`/`missing` with a warning.
"""
struct RecorderProfile
    name::String
    filename_style::Symbol
    split_char::Union{Char,Nothing}
    date_token::Union{Int,Nothing}
    time_token::Union{Int,Nothing}
    datetime_token::Union{Int,Nothing}
    datetime_format::Union{String,Nothing}
    site_token::Union{Int,Nothing}
    recorder_id_token::Union{Int,Nothing}
    timezone_source::Symbol
    has_xml::Bool
    parser::Union{Nothing,Function}
end

"""
    RECORDER_PROFILES

Registry of known recorder profiles, keyed by a short recorder ID
string (e.g. "rockhopper", "ls1x", "sm3m", "dmon2").

`parse_filename` will look up `RECORDER_PROFILES[recorder]` to decide
how to interpret the filename. New recorders can be added by extending
this dictionary and, if needed, defining a custom `parser` function.
"""
const RECORDER_PROFILES = Dict{String,RecorderProfile}()

# Rockhopper profile (example filename: 139635MD01_197K_A6M_RH428_20231012_000654Z.flac)
RECORDER_PROFILES["rockhopper"] = RecorderProfile(
    "Rockhopper",
    :tokenized,
    '_',     # split_char
    5,       # date_token ("20231012")
    6,       # time_token ("000654Z")
    nothing, # datetime_token
    "yyyymmdd_HHMMSSZ",  # datetime_format: date*time, with literal Z
    3,       # site_token ("A6M")
    4,       # recorder_id_token ("RH428")
    :suffix_Z,
    false,   # has_xml
    nothing  # parser => use generic token-based parser
)

# SM3M profile (example filename: T1-C__0__20170912_181500.wav)
RECORDER_PROFILES["sm3m"] = RecorderProfile(
    "SM3M",
    :tokenized,
    '_',
    5,                 # date_token
    6,                 # time_token
    nothing,           # datetime_token
    "yyyymmdd_HHMMSS", # "20170912_181500"
    1,                 # site_token ("T1-C")
    nothing,           # recorder_id_token
    :none,             # no special timezone handling
    false,
    nothing,
)

# LS1X profile (example filename: 20210319T163400_2614231252441225_2.0dB_3.8V_ver2.00.wav)
RECORDER_PROFILES["ls1x"] = RecorderProfile(
    "LS1X",
    :tokenized,
    '_',
    nothing,              # date_token
    nothing,              # time_token
    1,                    # datetime_token ("20210319T163400")
    "yyyymmddTHHMMSS",    # datetime_format
    nothing,              # site_token
    2,                    # recorder_id_token ("2614231252441225")
    :none,
    false,
    nothing,
)

# SNAP profile (example filename: T3C_180630_235000.wav)

# SNAP-specific helper
#
# Files are renamed as: T3C_YYMMDD_HHMMSS.wav
# Example: "T3C_180630_235000.wav"
#
# We currently assume all SNAP data are from 2000–2099 and map
# YY -> 20YY, e.g. "18" -> 2018. If you have older data, this
# logic MUST be revisited.

# This assumption is SNAP-only and does not affect other recorders.
function _parse_snap_filename(basename_noext::AbstractString)
    tokens = split(basename_noext, '_')
    if length(tokens) < 3
        return (timestamp   = nothing,
                timezone    = nothing,
                lat         = missing,
                lon         = missing,
                site_id     = nothing,
                recorder_id = nothing)
    end

    site_id = tokens[1]
    date6   = tokens[2]   # "180630"
    time    = tokens[3]   # "235000"

    # Expect YYMMDD; if not 6 chars, don't guess.
    if length(date6) != 6
        return (timestamp   = nothing,
                timezone    = nothing,
                lat         = missing,
                lon         = missing,
                site_id     = site_id,
                recorder_id = nothing)
    end

    # SNAP assumption: all deployments are 20YY, not 19YY.
    full_date = "20" * date6              # "180630" -> "20180630"
    dtstr     = full_date * "_" * time    # "20180630_235000"

    ts = DateTime(dtstr, DateFormat("yyyymmdd_HHMMSS"))

    return (timestamp   = ts,
            timezone    = nothing,
            lat         = missing,
            lon         = missing,
            site_id     = site_id,
            recorder_id = nothing)
end

RECORDER_PROFILES["snap"] = RecorderProfile(
    "SNAP (renamed)",
    :tokenized,
    '_',
    2,                     # date_token ("180630")
    3,                     # time_token ("235000")
    nothing,               # datetime_token
    "yyyymmdd_HHMMSS",     # for "20180630_235000"
    1,                     # site_token ("T3C")
    nothing,               # recorder_id_token
    :none,
    false,
    _parse_snap_filename,  # <--- use the helper here
)
