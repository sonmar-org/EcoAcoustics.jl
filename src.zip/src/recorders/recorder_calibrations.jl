"""
    CalibrationProfile

Static calibration parameters for a recorder family or model.

This is intentionally similar in spirit to `RecorderProfile`, but
focused on physical calibration rather than filename parsing.
"""
struct CalibrationProfile
    label::String                       # human-readable description
    sensitivity::Float64               # hydrophone sensitivity [dB re 1 V/µPa]
    preamp_gain::Float64               # preamp gain [dB]
    board_gain::Float64                # board/ADC gain [dB]
    Vadc_0pk::Float64                  # ADC full-scale peak voltage [V]
    tf_path::Union{String,Nothing}     # optional TF file path (Phase II+)
end

"""
    CALIBRATION_PROFILES

Registry of calibration profiles keyed by recorder name (lowercase).

For now this is keyed at the recorder-family level (e.g. `"sm3m"`).
This can extended to handle per-serial or per-deployment
differences, if needed.
"""
const CALIBRATION_PROFILES = Dict{String,CalibrationProfile}()

# --- SM3M default calibration profile ---
# Values from the old `hydrophones.jl`:
#   sensitivity = -165.0 dB re 1 V/µPa
#   preamp_gain =  12.0 dB
#   board_gain  =   0.0 dB
#   Vadc_0pk    =   1.0 V peak
#
# Total scalar sensitivity in dB will be computed later as:
#   S_total = sensitivity + preamp_gain + board_gain + 20*log10(1/Vadc_0pk)
CALIBRATION_PROFILES["sm3m"] = CalibrationProfile(
    "SM3M default",
    -165.0,   # sensitivity
    +12.0,    # preamp gain
    0.0,      # board gain
    1.0,      # Vadc_0pk
    nothing,  # no TF file yet
)

"""
    lookup_calibration(path, recorder, meta; strict=false)

Return a `Calibration` object for this recording.
"""
function lookup_calibration(path::AbstractString,
                            recorder::AbstractString,
                            meta;
                            strict::Bool=false)

    # normalize key
    key = lowercase(recorder)

    # If we have a calibration profile, apply it
    if haskey(CALIBRATION_PROFILES, key)
        cal_prof = CALIBRATION_PROFILES[key]

        # total scalar sensitivity (Phase I: scalar only)
        sens_db = cal_prof.sensitivity +
                  cal_prof.preamp_gain +
                  cal_prof.board_gain +
                  20 * log10(1 / cal_prof.Vadc_0pk)

        return ScalarCalibration(Float32(sens_db))
    end

    # fallback
    if strict
        @warn "No calibration entry for recorder, using NoCalibration()." (
            recorder    = recorder,
            site_id     = get(meta, :site_id, nothing),
            recorder_id = get(meta, :recorder_id, nothing),
        )
    end

    return NoCalibration()
end
